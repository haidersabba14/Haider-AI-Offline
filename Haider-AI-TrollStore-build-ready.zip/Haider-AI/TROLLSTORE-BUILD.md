# Haider AI → iPhone IPA for TrollStore

This project has **source code, not a compiled IPA**. The included GitHub Actions workflow compiles the native iOS app using a macOS hosted runner and packages its actual `.app` into `Haider-AI-TrollStore.ipa`, **only after a successful real build**. A failure or a missing configuration is not treated as success. No Apple Developer provisioning certificate is used by this unsigned build route. TrollStore is responsible for installation/signing on eligible devices.

## Compatibility

- TrollStore (official opa334): iOS/iPadOS **14.0 beta 2–16.6.1**, **16.7 RC**, and **17.0**; it does **not** support 17.0.1 or newer.
- This app uses **Expo SDK 58**, whose minimum iOS is **16.4**. Therefore use a TrollStore device on **16.4–16.6.1, 16.7 RC or 17.0**. On iOS 14/15 and most iOS 16 versions it is not compatible with this app; porting to an older SDK is a separate task.
- If the device is on iOS 27, TrollStore itself does not work on that device.
- Installing an unsigned release app through TrollStore is an advanced deployment method, not App Store distribution or guaranteed compatibility with every entitlement/plugin.

References:
- https://github.com/opa334/TrollStore
- https://docs.expo.dev/versions/v58.0.0/
- https://github.blog/changelog/2026-02-26-macos-26-is-now-generally-available-for-github-hosted-runners/

## Build from your GitHub repository, without a Mac

1. Create a new GitHub repository you own. Upload the contents of the **Haider-AI** folder, including the hidden `.github/workflows/build-trollstore-ipa.yml` file, **to the repository root**. Never upload a `.env` with private keys.
2. Complete your **real Supabase, SMTP/Resend and Cloudflare Worker** setup following `README.md`. The app cannot complete OTP/auth/chat without these actual services.
3. In your repository Settings → Secrets and variables → Actions:
   - Repository Variables: `EXPO_PUBLIC_SUPABASE_URL` = actual project HTTPS URL; `EXPO_PUBLIC_API_URL` = real Cloudflare Worker HTTPS URL.
   - Repository Secret: `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` = actual Supabase publishable/anon client key (not the admin/service-role key). This is a *client* key, and it will be embedded in the mobile app; RLS must still protect your data.
4. Repository → Actions → **Build Haider AI IPA for TrollStore** → **Run workflow**.
5. Check the build log. **If successful**, open the workflow run's Artifacts section and download `Haider-AI-TrollStore-IPA.zip`. Unzip it. Its contents include `Haider-AI-TrollStore.ipa` and an SHA-256 file.
6. Transfer the `.ipa` to your supported iPhone, choose **Share → TrollStore** (or use the + button in TrollStore). Only install builds you trust.

GitHub-hosted macOS builds use Actions minutes and availability according to the repository/account's plan. This build workflow has been prepared but has **not been executed or confirmed successful** in this chat. Possible issues: Expo/native dependency compatibility, available runner architecture, or unsigned app entitlements. Resolve from real build logs rather than assuming success.

## Never send these keys in chat or bundle them in the IPA

- Supabase `service_role` or other admin/server secret
- OpenAI/Anthropic/Gemini provider API keys
- Resend SMTP credential
- Cloudflare API token or R2 secret

Keep these in respective server dashboards using their secret managers.
