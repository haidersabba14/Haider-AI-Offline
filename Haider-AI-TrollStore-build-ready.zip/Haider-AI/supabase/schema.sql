-- HAIDER AI • database schema • run in Supabase SQL editor as project owner
-- These tables require Supabase Auth. Never disable RLS for troubleshooting.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '', avatar_url text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'محادثة جديدة',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid not null,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 50000),
  created_at timestamptz not null default now(),
  constraint messages_owner_conversation_fk foreign key (conversation_id,user_id)
    references public.conversations(id,user_id) on delete cascade
);
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, description text not null default '', metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.ai_tasks (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('research')), prompt text not null,
  status text not null default 'queued' check(status in ('queued','working','done','failed')),
  result text, error text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.generated_files (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  filename text not null, mime_type text not null, size_bytes bigint not null check (size_bytes >= 0),
  r2_key text not null unique, created_at timestamptz not null default now()
);
create table if not exists public.user_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  locale text not null default 'ar', theme text not null default 'dark', memory_enabled boolean not null default false
);
create table if not exists public.memory_entries (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  content text not null, created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, body text not null, read_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.usage_records (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null, model text not null, input_tokens integer not null default 0,
  output_tokens integer not null default 0, created_at timestamptz not null default now()
);

-- Native atomic request gate, not a billing-grade token/cost quota.
create table if not exists public.chat_quota (
  user_id uuid not null references auth.users(id) on delete cascade,
  window_start timestamptz not null, request_count integer not null default 0,
  primary key (user_id,window_start)
);

create index if not exists idx_conversations_user_time on public.conversations(user_id,updated_at desc);
create index if not exists idx_messages_conversation_time on public.messages(conversation_id,created_at);
create index if not exists idx_projects_user on public.projects(user_id,created_at desc);
create index if not exists idx_ai_tasks_user on public.ai_tasks(user_id,created_at desc);
create index if not exists idx_generated_files_user on public.generated_files(user_id,created_at desc);
create index if not exists idx_notifications_user on public.notifications(user_id,created_at desc);
create index if not exists idx_memory_user on public.memory_entries(user_id);
create index if not exists idx_usage_user on public.usage_records(user_id,created_at desc);

create or replace function public.on_auth_user_created() returns trigger language plpgsql security definer
set search_path = '' as $$
begin
  insert into public.profiles (user_id,display_name) values (new.id,coalesce(new.raw_user_meta_data->>'full_name','')) on conflict do nothing;
  insert into public.user_preferences (user_id) values (new.id) on conflict do nothing;
  return new;
end; $$;
drop trigger if exists auth_user_created on auth.users;
create trigger auth_user_created after insert on auth.users for each row execute procedure public.on_auth_user_created();

-- Enables RLS on every user-owned table, including the internal quota table.
do $$ declare t text;
begin
  foreach t in array array['profiles','conversations','messages','projects','ai_tasks','generated_files','user_preferences','memory_entries','notifications','usage_records','chat_quota'] loop
    execute format('alter table public.%I enable row level security',t);
    execute format('drop policy if exists owner_select on public.%I',t);
    execute format('drop policy if exists owner_insert on public.%I',t);
    execute format('drop policy if exists owner_update on public.%I',t);
    execute format('drop policy if exists owner_delete on public.%I',t);
    if t not in ('chat_quota','usage_records') then
      execute format('create policy owner_select on public.%I for select to authenticated using ((select auth.uid()) = user_id)',t);
      execute format('create policy owner_insert on public.%I for insert to authenticated with check ((select auth.uid()) = user_id)',t);
      execute format('create policy owner_update on public.%I for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id)',t);
      execute format('create policy owner_delete on public.%I for delete to authenticated using ((select auth.uid()) = user_id)',t);
    elsif t = 'usage_records' then
      execute format('create policy owner_select on public.%I for select to authenticated using ((select auth.uid()) = user_id)',t);
    end if;
  end loop;
end $$;

-- Gate enforces 30 AI requests per user per rolling hour-bucket atomically.
create or replace function public.claim_chat_quota() returns boolean
language plpgsql security definer set search_path = '' as $$
declare user_uuid uuid := (select auth.uid()); window_ts timestamptz := date_trunc('hour', now());
begin
  if user_uuid is null then return false; end if;
  insert into public.chat_quota(user_id,window_start,request_count)
  values (user_uuid,window_ts,1)
  on conflict (user_id,window_start) do update
    set request_count = public.chat_quota.request_count + 1
    where public.chat_quota.request_count < 30;
  return found;
end; $$;
revoke all on function public.claim_chat_quota() from public, anon;
grant execute on function public.claim_chat_quota() to authenticated;

-- Limit direct database access. Service role bypasses RLS only inside protected Worker.
revoke all on public.chat_quota from anon,authenticated;
revoke all on public.usage_records from anon;
grant select on public.usage_records to authenticated;
