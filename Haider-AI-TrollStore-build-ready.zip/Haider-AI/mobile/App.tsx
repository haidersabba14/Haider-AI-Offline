import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Linking, Platform,
  ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as DocumentPicker from 'expo-document-picker';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Session } from '@supabase/supabase-js';
import { authorized, chatStream, uploadFile } from './src/api';
import { configured, supabase } from './src/supabase';

const palette = { bg:'#080611', panel:'#171124', line:'#392d4b', violet:'#9966FF', bright:'#C9A6FF', text:'#F8F5FF', muted:'#B3A8C8', pink:'#EBA9FF' };
type Conversation = { id:string; title:string; updated_at:string };
type Message = { id:string; role:'user'|'assistant'; content:string; created_at?:string };
type Uploaded = { id:string; filename:string; size_bytes:number; created_at:string };
type Tab = 'chat'|'files'|'account';
function Brand({ big=false }: { big?: boolean }) {
  return <View style={{ flexDirection:'row',alignItems:'center',justifyContent:'center',gap:9 }}>
    <Text style={{ color:palette.bright,fontSize:big?45:30,fontWeight:'900' }}>✦</Text>
    <Text style={{ color:palette.text,fontSize:big?31:23,fontWeight:'900',letterSpacing:1 }}>HAIDER<Text style={{color:palette.bright}}> AI</Text></Text>
  </View>;
}
function GradientButton({ label, onPress, disabled=false }: { label:string;onPress:()=>void;disabled?:boolean }) {
  return <TouchableOpacity onPress={onPress} disabled={disabled} activeOpacity={0.8} style={{ opacity:disabled ? 0.55 : 1 }}>
    <LinearGradient colors={['#A36EFF','#6439BA']} start={{x:0,y:0}} end={{x:1,y:1}} style={styles.primaryButton}>
      <Text style={styles.primaryText}>{label}</Text>
    </LinearGradient>
  </TouchableOpacity>;
}
function Auth({ onReady }: {onReady:()=>void}) {
  const [email,setEmail] = useState('');
  const [otp,setOtp] = useState('');
  const [password,setPassword] = useState('');
  const [screen,setScreen] = useState<'email'|'verify'|'password'|'reset'>('email');
  const [busy,setBusy] = useState(false);
  const [sentAt,setSentAt] = useState(0);
  const [notice,setNotice] = useState('');
  const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const action = async (fn:()=>Promise<void>) => {
    setBusy(true);setNotice('');
    try { await fn(); } catch(e:any) { setNotice(e?.message || 'تعذّر إكمال العملية'); }
    finally { setBusy(false); }
  };
  const sendOtp = () => action(async () => {
    if (!isValidEmail) throw new Error('اكتب بريدًا إلكترونيًا صحيحًا');
    if (Date.now() - sentAt < 60000) throw new Error('انتظر دقيقة قبل إعادة إرسال الرمز');
    const {error} = await supabase.auth.signInWithOtp({ email:email.trim().toLowerCase(), options: { shouldCreateUser:true } });
    if (error) throw error;
    setSentAt(Date.now());setScreen('verify');
    setNotice('تم قبول طلب إرسال الرمز. افتح بريدك وتحقق من الرسالة.');
  });
  const verify = () => action(async () => {
    if (!/^\d{6,8}$/.test(otp.trim())) throw new Error('أدخل رمز التحقق المرسل بالبريد');
    const {data,error} = await supabase.auth.verifyOtp({email:email.trim().toLowerCase(),token:otp.trim(),type:'email'});
    if (error || !data.session) throw error || new Error('لم يتم إنشاء جلسة');
    onReady();
  });
  const signInPassword = () => action(async () => {
    if (!isValidEmail || !password) throw new Error('اكتب البريد وكلمة المرور');
    const {error} = await supabase.auth.signInWithPassword({email:email.trim().toLowerCase(),password});
    if (error) throw error;
    onReady();
  });
  const signUpPassword = () => action(async () => {
    if (!isValidEmail || password.length < 8) throw new Error('أدخل بريدًا صحيحًا وكلمة مرور من 8 أحرف على الأقل');
    const {error} = await supabase.auth.signUp({email:email.trim().toLowerCase(),password});
    if (error) throw error;
    setScreen('email');setNotice('تحقق من بريدك الإلكتروني لتأكيد التسجيل، ثم سجّل الدخول.');
  });
  const resetPassword = () => action(async () => {
    if (!isValidEmail) throw new Error('أدخل بريدًا صحيحًا');
    const {error} = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {redirectTo:'haiderai://auth/reset'});
    if (error) throw error;
    setNotice('إذا كان البريد مسجّلًا، ستصلك رسالة استعادة كلمة المرور.');
  });
  return <View style={styles.authContainer}>
    <View style={{ marginBottom:26 }}><Brand big/><Text style={styles.tagline}>ONE INTELLIGENCE. UNLIMITED POSSIBILITIES.</Text></View>
    <LinearGradient colors={['#221639','#110D1D']} style={styles.authPanel}>
      <Text style={styles.heroTitle}>{screen==='verify'?'تأكيد حسابك':screen==='reset'?'استعادة كلمة المرور':'مرحبًا بك 👑'}</Text>
      <Text style={styles.subtitle}>{screen==='verify'?'أدخل الرمز الحقيقي الذي وصلك عبر البريد':'مساعدك الذكي، في مكان واحد.'}</Text>
      <TextInput value={email} onChangeText={setEmail} placeholder="البريد الإلكتروني" placeholderTextColor="#857798" autoCapitalize="none" keyboardType="email-address" style={styles.input} editable={!busy && screen!=='verify'}/>
      {screen==='verify' && <TextInput value={otp} onChangeText={setOtp} placeholder="رمز التحقق" placeholderTextColor="#857798" keyboardType="number-pad" style={[styles.input,{textAlign:'center',fontSize:27,letterSpacing:6}]} maxLength={8}/>}
      {screen==='password' && <TextInput value={password} onChangeText={setPassword} placeholder="كلمة المرور" placeholderTextColor="#857798" secureTextEntry style={styles.input}/>}
      {!!notice && <Text style={styles.notice}>{notice}</Text>}
      {screen==='email' && <GradientButton label={busy?'جارٍ الإرسال...':'إرسال رمز التحقق ←'} onPress={sendOtp} disabled={busy}/>}
      {screen==='verify' && <><GradientButton label={busy?'جارٍ التحقق...':'تأكيد الرمز والدخول ✓'} onPress={verify} disabled={busy}/><TouchableOpacity onPress={sendOtp} disabled={busy}><Text style={styles.subAction}>إعادة إرسال الرمز بعد 60 ثانية</Text></TouchableOpacity></>}
      {screen==='password' && <><GradientButton label={busy?'جارٍ الدخول...':'الدخول بكلمة المرور'} onPress={signInPassword} disabled={busy}/><TouchableOpacity onPress={signUpPassword} disabled={busy}><Text style={styles.subAction}>إنشاء حساب بكلمة مرور</Text></TouchableOpacity><TouchableOpacity onPress={()=>{setScreen('reset');setNotice('')}}><Text style={styles.subAction}>نسيت كلمة المرور؟</Text></TouchableOpacity></>}
      {screen==='reset' && <GradientButton label="إرسال رابط الاستعادة" onPress={resetPassword} disabled={busy}/>}
      <TouchableOpacity onPress={()=>{setScreen(screen==='email'?'password':'email');setNotice('');setOtp('')}} style={{marginTop:22}}>
        <Text style={{textAlign:'center',color:palette.bright,fontWeight:'700'}}>{screen==='email'?'الدخول بكلمة مرور':'العودة لتسجيل الدخول بالرمز'}</Text>
      </TouchableOpacity>
    </LinearGradient>
    <Text style={styles.securityLine}>🔒 تسجيل دخول آمن عبر Supabase Auth</Text>
  </View>;
}
function Workspace({session}:{session:Session}) {
  const [tab,setTab] = useState<Tab>('chat');
  const [conversations,setConversations] = useState<Conversation[]>([]);
  const [active,setActive] = useState<string|null>(null);
  const [messages,setMessages] = useState<Message[]>([]);
  const [files,setFiles] = useState<Uploaded[]>([]);
  const [text,setText] = useState('');
  const [streaming,setStreaming] = useState(false);
  const [loading,setLoading] = useState(false);
  const [notice,setNotice] = useState('');
  const scroll = useRef<ScrollView>(null);
  const currentId = useRef<string|null>(null);
  const loadConversations = useCallback(async () => {
    const {data,error} = await supabase.from('conversations').select('id,title,updated_at').order('updated_at',{ascending:false}).limit(100);
    if (error) throw error;
    setConversations(data || []);
  },[]);
  const loadMessages = useCallback(async (id:string) => {
    const {data,error} = await supabase.from('messages').select('id,role,content,created_at').eq('conversation_id',id).order('created_at',{ascending:true}).limit(200);
    if (error) throw error;
    if (currentId.current === id) setMessages((data || []) as Message[]);
  },[]);
  const loadFiles = useCallback(async () => {
    const {data,error} = await supabase.from('generated_files').select('id,filename,size_bytes,created_at').order('created_at',{ascending:false}).limit(100);
    if (error) throw error;
    setFiles(data || []);
  },[]);
  useEffect(()=>{loadConversations().catch((e)=>setNotice(e.message));},[loadConversations]);
  useEffect(()=>{if(tab==='files')loadFiles().catch((e)=>setNotice(e.message));},[tab,loadFiles]);
  const choose = (id:string|null) => {
    if(streaming) return;
    currentId.current = id;setActive(id);setMessages([]);setNotice('');
    if(id){setLoading(true);loadMessages(id).catch((e)=>setNotice(e.message)).finally(()=>setLoading(false));}
  };
  const send = async () => {
    const message = text.trim();
    if(!message || streaming)return;
    setText('');setNotice('');setTab('chat');setStreaming(true);
    const originalId = currentId.current;
    setMessages(old=>[...old,{id:`local-${Date.now()}`,role:'user',content:message},{id:'streaming',role:'assistant',content:''}]);
    try {
      await chatStream(message,originalId,(event,data)=>{
        if(event==='meta' && data.conversationId){currentId.current=data.conversationId;setActive(data.conversationId);}
        if(event==='token') setMessages(old=>old.map(m=>m.id==='streaming'?{...m,content:m.content+data.text}:m));
      });
      const savedId=currentId.current;
      await loadConversations();
      if(savedId) await loadMessages(savedId);
    } catch(e:any) {
      setNotice(e?.message || 'تعذّر إرسال الرسالة');
      setMessages(old=>old.filter(m=>m.id!=='streaming'));
      await loadConversations().catch(()=>{});
    } finally {setStreaming(false);}
  };
  const selectUpload = async () => {
    try {
      const chosen=await DocumentPicker.getDocumentAsync({copyToCacheDirectory:true,type:['image/*','application/pdf','text/plain','application/zip']});
      if(chosen.canceled)return;
      const file=chosen.assets[0];
      if((file.size||0)>10*1024*1024){Alert.alert('الملف كبير','الحد الأقصى 10MB');return;}
      setLoading(true);
      await uploadFile(file.uri,file.name,file.mimeType||'application/octet-stream');
      await loadFiles();setNotice('تم رفع الملف إلى التخزين الخاص بك بنجاح');
    } catch(e:any){setNotice(e.message||'فشل رفع الملف');}
    finally{setLoading(false);}
  };
  const shareFile = async (item:Uploaded) => {
    setLoading(true);
    try {
      const resp=await authorized(`/v1/files/${item.id}`);
      if(!resp.ok)throw new Error('تعذّر تنزيل الملف');
      const safe=item.filename.replace(/[^\p{L}\p{N}._-]/gu,'_');
      const file=new File(Paths.cache,`${item.id}-${safe}`);
      file.create({ overwrite: true });
      file.write(new Uint8Array(await resp.arrayBuffer()));
      if(await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri);
      else Alert.alert('حُفظ الملف',file.uri);
    }catch(e:any){setNotice(e.message);}finally{setLoading(false);}
  };
  const requestDelete = () => {
    Alert.alert('حذف حساب Haider AI','سيتم حذف الحساب والمحادثات والملفات نهائيًا. لا يمكن التراجع.',[
      {text:'إلغاء',style:'cancel'},
      {text:'حذف الحساب',style:'destructive',onPress:async()=>{
        try{const resp=await authorized('/v1/account',{method:'DELETE'});if(!resp.ok)throw new Error((await resp.json()).error||'تعذّر حذف الحساب');await supabase.auth.signOut();}
        catch(e:any){Alert.alert('فشل الحذف',e.message);}
      }}
    ]);
  };
  return <View style={styles.workspace}>
    <View style={styles.topBar}>
      <View><Text style={{color:palette.muted,fontSize:11,letterSpacing:2}}>YOUR INTELLIGENCE</Text><Text style={styles.topTitle}>✦ Haider AI</Text></View>
      <View style={styles.avatar}><Text style={{color:'white',fontWeight:'900'}}>H</Text></View>
    </View>
    {tab==='chat' && <>
      <View style={styles.chatHeading}>
        <Text style={styles.sectionTitle}>HAIDER <Text style={{color:palette.bright}}>CORE</Text></Text>
        <TouchableOpacity onPress={()=>choose(null)} style={styles.outlineSmall}><Text style={{color:palette.bright,fontSize:13}}>＋ محادثة</Text></TouchableOpacity>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{flexGrow:0,maxHeight:60}} contentContainerStyle={{paddingHorizontal:17,alignItems:'center',gap:8}}>
        {conversations.map(c=><TouchableOpacity key={c.id} onPress={()=>choose(c.id)} style={[styles.convoChip,active===c.id&&styles.convoChipActive]}><Text numberOfLines={1} style={{color:active===c.id?'#fff':palette.muted,fontSize:12,maxWidth:155}}>{c.title}</Text></TouchableOpacity>)}
      </ScrollView>
      <ScrollView ref={scroll} style={{flex:1}} contentContainerStyle={{padding:20,paddingBottom:30,flexGrow:1}} onContentSizeChange={()=>scroll.current?.scrollToEnd({animated:true})} keyboardShouldPersistTaps="handled">
        {loading&&<ActivityIndicator color={palette.bright}/>}
        {messages.length===0 && !loading && <View style={styles.welcome}>
          <LinearGradient colors={['#2B1C4D','#160E26']} style={styles.orb}><Text style={{color:palette.bright,fontSize:62}}>✦</Text></LinearGradient>
          <Text style={styles.welcomeTitle}>ذكاء يفهم طموحك.</Text>
          <Text style={styles.welcomeSubtitle}>اكتب سؤالك، اطلب كودًا أو حلّل فكرة. المحادثات تُحفظ في حسابك الحقيقي.</Text>
          <View style={{gap:10,marginTop:22,width:'100%'}}>
            {['اكتب لي فكرة تطبيق احترافي','ساعدني في حل مشكلة برمجية','اشرح لي موضوعًا معقدًا'].map(s=><TouchableOpacity key={s} onPress={()=>setText(s)} style={styles.promptChip}><Text style={{color:'#E7DFFA',textAlign:'right'}}>✦  {s}</Text></TouchableOpacity>)}
          </View>
        </View>}
        {messages.map(m=><View key={m.id} style={[styles.bubble,m.role==='user'?styles.userBubble:styles.aiBubble]}>
          <Text style={{color:m.role==='user'?'#E7D9FF':palette.bright,fontSize:11,fontWeight:'800',marginBottom:6}}>{m.role==='user'?'أنت':'✦ HAIDER CORE'}</Text>
          <Text selectable style={{color:palette.text,fontSize:15,lineHeight:24,textAlign:'right'}}>{m.content || (streaming?'يكتب الآن...':'')}</Text>
        </View>)}
      </ScrollView>
      {!!notice && <Text style={styles.inlineError}>{notice}</Text>}
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} keyboardVerticalOffset={90}>
        <View style={styles.composer}>
          <TouchableOpacity style={[styles.sendButton,{opacity:streaming?0.5:1}]} onPress={send} disabled={streaming}><Text style={{color:'white',fontSize:24}}>↑</Text></TouchableOpacity>
          <TextInput style={styles.messageInput} value={text} onChangeText={setText} placeholder="اسأل Haider Core..." placeholderTextColor="#9586AD" multiline maxLength={6000} editable={!streaming}/>
        </View>
      </KeyboardAvoidingView>
    </>}
    {tab==='files' && <ScrollView contentContainerStyle={{padding:20,gap:14}}>
      <Text style={styles.sectionTitle}>ملفاتي الآمنة</Text>
      <Text style={styles.subtitle}>الملفات محفوظة على Cloudflare R2 بعد تفعيل الحاوية. الوصول يتطلب جلسة المستخدم.</Text>
      <GradientButton label="＋ رفع ملف حتى 10MB" onPress={selectUpload} disabled={loading}/>
      {!!notice&&<Text style={styles.inlineError}>{notice}</Text>}
      {files.map(f=><TouchableOpacity key={f.id} style={styles.fileRow} onPress={()=>shareFile(f)}><Text style={{fontSize:26}}>📄</Text><View style={{flex:1}}><Text style={{color:palette.text,fontWeight:'600',textAlign:'right'}}>{f.filename}</Text><Text style={{color:palette.muted,textAlign:'right',fontSize:12}}>{Math.ceil(f.size_bytes/1024)} KB · اضغط لتنزيله</Text></View></TouchableOpacity>)}
      {!files.length&&<Text style={styles.empty}>لا توجد ملفات محفوظة بعد.</Text>}
    </ScrollView>}
    {tab==='account' && <ScrollView contentContainerStyle={{padding:22,gap:18}}>
      <Brand big/><Text style={[styles.subtitle,{textAlign:'center'}]}>حسابك في Haider AI</Text>
      <View style={styles.accountCard}><Text style={styles.accountLabel}>البريد الإلكتروني</Text><Text style={styles.accountValue}>{session.user.email}</Text></View>
      <View style={styles.accountCard}><Text style={styles.accountLabel}>معرّف حسابك الآمن</Text><Text selectable style={[styles.accountValue,{fontSize:12}]}>{session.user.id}</Text></View>
      <TouchableOpacity style={styles.secondaryButton} onPress={async()=>{await supabase.auth.signOut()}}><Text style={styles.secondaryText}>تسجيل الخروج</Text></TouchableOpacity>
      <TouchableOpacity style={[styles.secondaryButton,{borderColor:'#93495B'}]} onPress={requestDelete}><Text style={{color:'#FF9BAC',textAlign:'center',fontWeight:'800'}}>حذف حسابي وبياناتي نهائيًا</Text></TouchableOpacity>
      <Text style={styles.securityLine}>🔒 جلسات آمنة ومزامنة عبر Supabase</Text>
    </ScrollView>}
    <View style={styles.tabBar}>
      {([['chat','✦','المحادثات'],['files','▣','الملفات'],['account','◉','حسابي']] as const).map(([k,i,l])=><TouchableOpacity key={k} onPress={()=>{if(streaming&&k!=='chat')return;setTab(k);setNotice('')}} style={styles.tab}><Text style={{fontSize:21,color:tab===k?palette.bright:palette.muted}}>{i}</Text><Text style={{fontSize:11,fontWeight:'700',color:tab===k?palette.bright:palette.muted}}>{l}</Text></TouchableOpacity>)}
    </View>
  </View>;
}
function Main() {
  const [session,setSession] = useState<Session|null>(null);
  const [pending,setPending] = useState(true);
  const [recover,setRecover] = useState(false);
  const [newPassword,setNewPassword] = useState('');
  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>{setSession(data.session);setPending(false)}).catch(()=>setPending(false));
    const {data:{subscription}}=supabase.auth.onAuthStateChange((event,session)=>{
      setSession(session);if(event==='PASSWORD_RECOVERY')setRecover(true);
    });
    // Handle Supabase password recovery deep link. Configure matching redirect in Supabase Dashboard.
    const handler=async ({url}:{url:string})=>{
      try{
        const fragment=url.split('#')[1]||'';
        const params=new URLSearchParams(fragment);
        const code=new URL(url).searchParams.get('code');
        if(code){const {error}=await supabase.auth.exchangeCodeForSession(code);if(error)throw error;setRecover(true);}
        else if(params.get('access_token')&&params.get('refresh_token')){
          const {error}=await supabase.auth.setSession({access_token:params.get('access_token')!,refresh_token:params.get('refresh_token')!});
          if(error)throw error;setRecover(true);
        }
      }catch(e:any){Alert.alert('خطأ في رابط الاستعادة',e?.message||'الرابط غير صالح');}
    };
    const linkSub=Linking.addEventListener('url',handler);
    Linking.getInitialURL().then(url=>{if(url)void handler({url})});
    return ()=>{subscription.unsubscribe();linkSub.remove()};
  },[]);
  if(!configured)return <SafeAreaView style={styles.root}><View style={styles.configMessage}><Brand big/><Text style={styles.heroTitle}>يلزم ربط السيرفرات</Text><Text style={styles.subtitle}>أدخل روابط ومفاتيح Supabase العامة وعنوان Cloudflare Worker الحقيقي في ملف .env لبناء التطبيق. لا توجد حسابات وهمية أو اتصال تجريبي.</Text></View></SafeAreaView>;
  if(pending)return <SafeAreaView style={styles.root}><ActivityIndicator size="large" color={palette.bright} style={{flex:1}}/></SafeAreaView>;
  if(recover&&session)return <SafeAreaView style={styles.root}><View style={styles.configMessage}><Brand big/><Text style={styles.heroTitle}>تعيين كلمة مرور جديدة</Text><TextInput style={styles.input} secureTextEntry placeholder="كلمة مرور جديدة (8 أحرف على الأقل)" placeholderTextColor="#9586AD" value={newPassword} onChangeText={setNewPassword}/><GradientButton label="تحديث كلمة المرور" onPress={async()=>{if(newPassword.length<8){Alert.alert('كلمة المرور قصيرة');return;}const{error}=await supabase.auth.updateUser({password:newPassword});if(error)Alert.alert('خطأ',error.message);else{setRecover(false);Alert.alert('تم تحديث كلمة المرور');}}}/></View></SafeAreaView>;
  return <SafeAreaView style={styles.root} edges={['top','bottom']}><StatusBar barStyle="light-content"/><>{session?<Workspace session={session}/>:<Auth onReady={()=>{}}/>}</></SafeAreaView>;
}
export default function App(){return <SafeAreaProvider><Main/></SafeAreaProvider>}

const styles=StyleSheet.create({
  root:{flex:1,backgroundColor:palette.bg},workspace:{flex:1},
  authContainer:{flex:1,justifyContent:'center',padding:22,backgroundColor:palette.bg},
  tagline:{color:palette.muted,fontSize:10,letterSpacing:1.2,textAlign:'center',marginTop:6},
  authPanel:{borderRadius:26,borderColor:'#443261',borderWidth:1,padding:24,gap:14},
  heroTitle:{color:palette.text,fontSize:28,fontWeight:'900',textAlign:'center'},
  subtitle:{color:palette.muted,fontSize:14,textAlign:'right',lineHeight:24},
  input:{backgroundColor:'#0D0A18',borderColor:palette.line,borderWidth:1,borderRadius:16,color:palette.text,paddingHorizontal:17,paddingVertical:16,fontSize:15,textAlign:'right'},
  notice:{color:palette.pink,fontSize:13,textAlign:'right',lineHeight:22},
  primaryButton:{borderRadius:16,alignItems:'center',justifyContent:'center',paddingVertical:17,minHeight:53},
  primaryText:{color:'white',fontSize:16,fontWeight:'900'},
  subAction:{color:palette.muted,textAlign:'center',marginTop:9,fontSize:12},
  securityLine:{color:'#8D809F',fontSize:12,textAlign:'center',marginTop:20},
  configMessage:{flex:1,justifyContent:'center',gap:25,padding:25},
  topBar:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:20,paddingVertical:18,borderBottomWidth:1,borderColor:'#241C31'},
  topTitle:{color:palette.text,fontWeight:'900',fontSize:25},
  avatar:{height:40,width:40,borderRadius:20,backgroundColor:'#523285',alignItems:'center',justifyContent:'center',borderColor:palette.violet,borderWidth:1},
  chatHeading:{paddingHorizontal:20,paddingTop:22,paddingBottom:9,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  sectionTitle:{fontSize:21,fontWeight:'900',color:palette.text},
  outlineSmall:{borderColor:palette.line,borderWidth:1,borderRadius:12,paddingHorizontal:13,paddingVertical:9},
  convoChip:{borderColor:'#403151',borderWidth:1,backgroundColor:'#151021',paddingHorizontal:12,paddingVertical:9,borderRadius:12},
  convoChipActive:{borderColor:palette.violet,backgroundColor:'#3B265B'},
  welcome:{flex:1,justifyContent:'center',alignItems:'center',gap:12},
  orb:{width:128,height:128,borderRadius:64,borderWidth:1,borderColor:'#5B388F',alignItems:'center',justifyContent:'center',marginBottom:10},
  welcomeTitle:{color:palette.text,fontSize:23,fontWeight:'900'},
  welcomeSubtitle:{color:palette.muted,lineHeight:23,textAlign:'center',maxWidth:290},
  promptChip:{padding:15,borderRadius:13,borderWidth:1,borderColor:palette.line,backgroundColor:'#160F23'},
  bubble:{borderRadius:17,padding:15,marginBottom:15,maxWidth:'90%',borderWidth:1},
  userBubble:{backgroundColor:'#34224E',borderColor:'#604284',alignSelf:'flex-end'},
  aiBubble:{backgroundColor:'#151122',borderColor:'#322341',alignSelf:'flex-start'},
  composer:{flexDirection:'row',alignItems:'center',paddingHorizontal:15,paddingVertical:14,gap:10,borderTopColor:'#2C223C',borderTopWidth:1,backgroundColor:'#100C1B'},
  messageInput:{backgroundColor:'#20162D',borderWidth:1,borderColor:'#43304D',borderRadius:15,padding:12,color:palette.text,flex:1,maxHeight:105,minHeight:51,textAlign:'right'},
  sendButton:{height:51,width:51,backgroundColor:palette.violet,borderRadius:15,alignItems:'center',justifyContent:'center'},
  inlineError:{color:'#FFB1C5',fontSize:12,textAlign:'center',paddingHorizontal:20,paddingVertical:7},
  tabBar:{flexDirection:'row',backgroundColor:'#100D19',borderTopColor:'#2C223C',borderTopWidth:1,paddingVertical:11,justifyContent:'space-around'},
  tab:{alignItems:'center',gap:4,minWidth:80},
  fileRow:{backgroundColor:palette.panel,borderColor:palette.line,borderWidth:1,borderRadius:15,padding:16,gap:14,flexDirection:'row',alignItems:'center'},
  empty:{color:palette.muted,textAlign:'center',marginTop:35},
  accountCard:{padding:20,borderRadius:17,borderColor:palette.line,borderWidth:1,backgroundColor:palette.panel,gap:9},
  accountLabel:{color:palette.muted,fontSize:12,textAlign:'right'},accountValue:{color:palette.text,textAlign:'right',fontWeight:'700',fontSize:15},
  secondaryButton:{padding:17,borderColor:palette.line,borderWidth:1,borderRadius:14},secondaryText:{color:palette.text,textAlign:'center',fontWeight:'800'}
});
