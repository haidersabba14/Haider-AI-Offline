import 'react-native-url-polyfill/auto';
import * as SecureStore from 'expo-secure-store';
import { AppState } from 'react-native';
import { createClient } from '@supabase/supabase-js';

// Large Supabase session objects are chunked for iOS Keychain / Android Keystore item limits.
const storage = {
  async getItem(key: string): Promise<string | null> {
    const count = Number(await SecureStore.getItemAsync(`${key}__n`) || '0');
    if (!count) return null;
    const parts: string[] = [];
    for (let i = 0; i < count; i++) {
      const part = await SecureStore.getItemAsync(`${key}__${i}`);
      if (part === null) return null;
      parts.push(part);
    }
    return parts.join('');
  },
  async setItem(key: string, value: string): Promise<void> {
    const oldCount = Number(await SecureStore.getItemAsync(`${key}__n`) || '0');
    const chunks = value.match(/[\s\S]{1,1500}/g) || [];
    for (let i = 0; i < chunks.length; i++) await SecureStore.setItemAsync(`${key}__${i}`, chunks[i]);
    await SecureStore.setItemAsync(`${key}__n`, String(chunks.length));
    for (let i = chunks.length; i < oldCount; i++) await SecureStore.deleteItemAsync(`${key}__${i}`);
  },
  async removeItem(key: string): Promise<void> {
    const oldCount = Number(await SecureStore.getItemAsync(`${key}__n`) || '0');
    await SecureStore.deleteItemAsync(`${key}__n`);
    for (let i = 0; i < oldCount; i++) await SecureStore.deleteItemAsync(`${key}__${i}`);
  }
};
export const configured = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY && process.env.EXPO_PUBLIC_API_URL && !process.env.EXPO_PUBLIC_API_URL.includes('YOUR_REAL_'));
const url = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://invalid.example.com';
const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY || 'unconfigured';
export const apiUrl = (process.env.EXPO_PUBLIC_API_URL || '').replace(/\/$/, '');
export const supabase = createClient(url, key, {
  auth: { storage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false }
});
AppState.addEventListener('change', state => {
  if (state === 'active') supabase.auth.startAutoRefresh();
  else supabase.auth.stopAutoRefresh();
});
