import { fetch } from 'expo/fetch';
import { File } from 'expo-file-system';
import { apiUrl, supabase } from './supabase';

async function token() {
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.access_token) throw new Error('انتهت الجلسة. سجّل الدخول مرة ثانية.');
  return data.session.access_token;
}
export async function authorized(path: string, init: RequestInit = {}) {
  const accessToken = await token();
  return fetch(`${apiUrl}${path}`, { ...init, headers: { ...(init.headers as Record<string,string> || {}), Authorization: `Bearer ${accessToken}` } });
}
export async function chatStream(text: string, conversationId: string | null, onEvent: (name: string, data: any) => void) {
  const response = await authorized('/v1/chat', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
    body: JSON.stringify({ text, conversationId })
  });
  if (!response.ok || !response.body) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'الخادم غير متاح');
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let pending = '';
  let finished = false;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      pending += decoder.decode(value, { stream: true });
      const events = pending.split(/\r?\n\r?\n/);
      pending = events.pop() || '';
      for (const part of events) {
        const event = /^event:\s*(.+)$/m.exec(part)?.[1]?.trim();
        const dataLine = /^data:\s*(.+)$/m.exec(part)?.[1];
        if (!event || !dataLine) continue;
        const data = JSON.parse(dataLine);
        if (event === 'error') throw new Error(data.error || 'تعذّر الرد');
        onEvent(event, data);
        if (event === 'done') finished = data.saved === true;
      }
    }
  } finally { reader.releaseLock(); }
  if (!finished) throw new Error('انقطع الاتصال قبل حفظ الرد');
}
export async function uploadFile(localUri: string, filename: string, mimeType: string) {
  const file = new File(localUri);
  const response = await authorized(`/v1/files?filename=${encodeURIComponent(filename)}`, {
    method: 'PUT', headers: { 'Content-Type': mimeType, 'Content-Length': String(file.size) }, body: file
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || 'تعذّر رفع الملف');
  return result;
}
