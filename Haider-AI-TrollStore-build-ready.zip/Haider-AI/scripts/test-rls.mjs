// Uses two REAL Supabase Auth JWTs. Proves client A cannot see or modify client B's data.
// Usage: SUPABASE_URL=... SUPABASE_PUBLISHABLE_KEY=... TEST_TOKEN_A=... TEST_TOKEN_B=... node scripts/test-rls.mjs
import assert from 'node:assert/strict';
const required=['SUPABASE_URL','SUPABASE_PUBLISHABLE_KEY','TEST_TOKEN_A','TEST_TOKEN_B'];
for(const n of required)if(!process.env[n])throw Error(`Missing ${n}`);
const base=process.env.SUPABASE_URL, key=process.env.SUPABASE_PUBLISHABLE_KEY;
const headers=(token)=>({apikey:key,Authorization:`Bearer ${token}`,'Content-Type':'application/json'});
const request=async (token,path,options={})=>{
 const response=await fetch(`${base}/rest/v1/${path}`,{...options,headers:{...headers(token),...options.headers}});
 const data=await response.json().catch(()=>null);
 return {status:response.status,data};
};
const who=async(token)=>{
 const response=await fetch(`${base}/auth/v1/user`,{headers:headers(token)});
 assert.equal(response.status,200,'Authentication failed');
 return (await response.json()).id;
};
const a=await who(process.env.TEST_TOKEN_A),b=await who(process.env.TEST_TOKEN_B);
assert.notEqual(a,b,'Tokens must belong to different real users');
const created=await request(process.env.TEST_TOKEN_A,'conversations?select=id,user_id',{
 method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify({user_id:a,title:'RLS integration test'})});
assert.equal(created.status,201,JSON.stringify(created.data));
const id=created.data[0].id;
try{
 const other=await request(process.env.TEST_TOKEN_B,`conversations?id=eq.${id}&select=*`);
 assert.equal(other.status,200);assert.deepEqual(other.data,[]);
 const update=await request(process.env.TEST_TOKEN_B,`conversations?id=eq.${id}&select=id`,{
 method:'PATCH',headers:{Prefer:'return=representation'},body:JSON.stringify({title:'FORBIDDEN'})});
 assert.equal(update.status,200);assert.deepEqual(update.data,[]);
 const spoof=await request(process.env.TEST_TOKEN_B,'conversations',{method:'POST',body:JSON.stringify({user_id:a,title:'FORBIDDEN'})});
 assert.ok(spoof.status===401||spoof.status===403,JSON.stringify(spoof));
 const tamper=await request(process.env.TEST_TOKEN_B,'messages',{
 method:'POST',body:JSON.stringify({conversation_id:id,user_id:b,role:'user',content:'FORBIDDEN'})});
 assert.ok(tamper.status>=400,JSON.stringify(tamper));
 console.log('PASS: Supabase RLS isolates both users and rejects cross-account writes.');
}finally{
 await request(process.env.TEST_TOKEN_A,`conversations?id=eq.${id}`,{method:'DELETE'});
}
