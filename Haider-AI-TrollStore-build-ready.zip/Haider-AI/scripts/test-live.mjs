// REAL integration test; never produces simulated OTP. User supplies actual code from email.
import readline from 'node:readline/promises';
import {stdin as input,stdout as output} from 'node:process';
const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_PUBLISHABLE_KEY, worker=process.env.API_URL, email=process.env.TEST_EMAIL;
if(!url||!key||!worker||!email)throw Error('Set SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, API_URL, TEST_EMAIL to actual deployed resources');
const headers={apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'};
const sent=await fetch(`${url}/auth/v1/otp`,{method:'POST',headers,body:JSON.stringify({email,create_user:true})});
if(!sent.ok)throw Error(`OTP request rejected: HTTP ${sent.status}`);
console.log('OTP request accepted. Check Resend delivery logs AND your inbox. Acceptance != delivery.');
const rl=readline.createInterface({input,output});
let code;
try{code=(await rl.question('Enter the actual OTP received in your email: ')).trim();}finally{rl.close();}
const verify=await fetch(`${url}/auth/v1/verify`,{method:'POST',headers,body:JSON.stringify({email,token:code,type:'email'})});
const session=await verify.json();
if(!verify.ok||!session.access_token)throw Error(`Verification failed: HTTP ${verify.status}`);
console.log('PASS: OTP verified and genuine Supabase session issued.');
const chat=await fetch(`${worker.replace(/\/$/,'')}/v1/chat`,{
 method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},
 body:JSON.stringify({text:'اكتب كلمة مرحبًا فقط'})
});
if(!chat.ok)throw Error(`AI request failed: HTTP ${chat.status} ${(await chat.text()).slice(0,200)}`);
const sse=await chat.text();
if(!sse.includes('event: token')||!sse.includes('event: done')||!sse.includes('"saved":true'))throw Error('AI reply not confirmed saved');
console.log('PASS: Real AI streamed and assistant message persisted.');
console.log('MANUAL: verify this conversation appears in app and on second device.');
