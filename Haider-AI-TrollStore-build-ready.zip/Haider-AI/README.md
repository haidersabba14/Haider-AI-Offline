# 👑 Haider AI — React Native + Supabase + Cloudflare Workers

**Current delivery: runnable source code / deployment starter, NOT a deployed production service and NOT an IPA/APK binary.** Nothing here sends real mail until your **own Supabase, Resend, OpenAI, Cloudflare** connections are configured. No mock user accounts or fake responses are used. Name: **Haider AI**, assistant: **HAIDER CORE**.

## What has been implemented

- **Mobile**: Expo / React Native SDK 58 project for iOS + Android; Arabic RTL-friendly black/purple interface; real OTP registration/login + optional existing password sign-in, password signup/reset, secure chunked session storage, conversation history, streamed response UI, file selection/upload and authenticated retrieval, logout, account removal.
- **Worker**: validated Supabase Auth JWT via remote `getUser`, real OpenAI chat completion streaming, RLS-scoped conversation and messages, hourly atomic user request gate, R2 private file storage when bound, trusted Cloudflare Queue research tasks when bound, account deletion with admin key on server.
- **SQL**: `profiles`, `conversations`, `messages`, `projects`, `ai_tasks`, `generated_files`, `user_preferences`, `memory_entries`, `notifications`, `usage_records`, private `chat_quota`; indexes, RLS policies, ownership FK and trigger.
- **Email**: branded HTML with `{{ .Token }}`. Real delivery depends on verified sending domain and Supabase SMTP setup.
- **Live tests**: OTP/email → session → AI streaming test, plus two-user RLS test. These do not fake success.

## 1. Supabase (required)

1. Create project at https://supabase.com/dashboard. Pick region and configure a strong database password privately.
2. SQL Editor → run `supabase/schema.sql`. Confirm execution and check Tables + RLS.
3. Authentication → Providers → Email enabled, confirm emails enabled. Enable email OTP / set the email templates below. Never disable email confirmation merely to pass a test.
4. Copy **Project URL** and **publishable/anon client key** for mobile and Worker. Keep **service_role/secret admin key only in the Worker secrets**. Do NOT put it in Expo `EXPO_PUBLIC_*` variables.
5. Configure the Auth URL settings / redirect allowlist to include `haiderai://auth/reset`. A valid domain URL should also be configured for your real website if available.

## 2. Resend SMTP (required for real OTP delivery)

1. Verify **a domain that you own** in https://resend.com/domains. Use DNS values provided by Resend to publish DKIM and SPF. Do not use `nexoraai.com` unless you own and verify it.
2. Supabase Dashboard → Authentication → SMTP Settings → enable custom SMTP:
   - Host `smtp.resend.com`
   - Port `465`
   - Username `resend`
   - Password **Resend API key / SMTP credential**, entered *only* in Supabase settings
   - From address `noreply@YOUR_VERIFIED_DOMAIN` and sender name `Haider AI`
3. Authentication → Email Templates: for **Magic Link** (and **Confirm Signup** if using password signups), customize the subjects and paste `supabase/verification-email.html`. Subject `Haider AI | رمز التحقق من حسابك`. The `{{ .Token }}` tag is essential for a numeric OTP rather than a magic link.
4. Verify the **actual** behavior of password-signup confirmation and recovery emails (a recovery template should include a working reset link; do not replace recovery links with this OTP-only template).
5. Set OTP expiry and minimum resend interval using Supabase Auth settings and security limits. The UI also applies a 60-second resend delay; the actual security limit belongs to Supabase.
6. Send to a mailbox you control and review both inbox **and Resend delivery log**. A success response from `signInWithOtp()` is not proof that email arrived.

## 3. Cloudflare Worker (required)

Commands (on a computer/host with Node 22+; optionally GitHub Codespaces):

```bash
cd worker
npm install
npx wrangler login
```

Edit `worker/wrangler.toml` with your **real** Supabase project URL and publishable key. Set secrets with terminal prompts (not inside project code, not via chat):

```bash
npx wrangler secret put OPENAI_API_KEY
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY
npm run deploy
```

`SUPABASE_SERVICE_ROLE_KEY` is needed for usage logging, Cloudflare Queue task execution, and account deletion, not for ordinary chat. `OPENAI_API_KEY` comes from your account and will incur provider charges.

Read the **actual** `https://haider-ai-api.<your-subdomain>.workers.dev` URL printed by Wrangler on deployment. Do **not** assume the URL works until you see a successful deploy and `/v1/health` responds. Your custom domain may be routed only after you own and configure its DNS zone.

### Optional R2 and Queues

Create R2 bucket and queue in Cloudflare, then uncomment the matching binding lines in `worker/wrangler.toml`:

```bash
npx wrangler r2 bucket create haider-ai-files
npx wrangler queues create haider-ai-tasks
npm run deploy
```

R2 upload is currently capped at 10 MB and permits PNG, JPEG, WEBP, PDF, text, and ZIP. Queue tasks currently implement a research-style **LLM response without live web search**. Image generation, video generation, third-party AI routing, Google/Apple OAuth, push delivery, and scheduled cron jobs **are not implemented or verified**. Configure official services and appropriate safety/cost controls before adding them.

## 4. Mobile app + IPA/APK cloud build

```bash
cd mobile
npm install
npx expo install --fix
cp .env.example .env
```

Edit `.env` with **real** project URL, publishable key, and **exact** deployed Worker HTTPS URL (`EXPO_PUBLIC_API_URL`). No secret API keys or service role keys belong there.

```bash
npx expo start
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
npx eas-cli device:create
npx eas-cli build --platform ios --profile preview
```

- Android **preview** build produces **APK** when successfully built/signed.
- iOS **preview** build can produce **IPA** when you have a valid **Apple Developer account**, correct signing credentials and registered test device UDID (ad hoc provisioning). EAS provides a **real installation URL** only after successful signing and build. An arbitrary HTTPS download link to an unsigned IPA does not make it installable.
- App ID defaults `com.haider.ai`. Change it if that bundle identifier is not available to your Apple team.
- See official EAS docs: https://docs.expo.dev/build/internal-distribution/
- Install on device with the **verified** EAS install link. This project intentionally contains no fabricated IPA, fake install link, or mock backend.

## 5. Test against actual accounts (required before public release)

From repo root:

```bash
SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLIC_KEY \
API_URL=https://YOUR_DEPLOYED_WORKER.workers.dev \
TEST_EMAIL=YOUR_MAILBOX@example.com \
node scripts/test-live.mjs
```

The script triggers the real OTP service, waits for **you to type the actual code delivered to your inbox**, verifies a real session and confirms an OpenAI streaming reply was saved. Review provider logs independently, then confirm the same conversation appears across both phone platforms.

For cross-user RLS test, obtain actual access JWTs for **two distinct test accounts** and run:

```bash
SUPABASE_URL=... SUPABASE_PUBLISHABLE_KEY=... \
TEST_TOKEN_A=... TEST_TOKEN_B=... node scripts/test-rls.mjs
```

Keep session tokens out of screenshots, public repositories, chat, logs, and shell history. Use temporary local test credentials and revoke them after tests.

## Security / production limitations

- Real API usage costs money; control **provider budgets and Cloudflare limits** separately. The 30-chat-requests/hour SQL gate is atomic but not a complete abuse protection layer; configure Cloudflare WAF/rate limiting for IP-level controls and Supabase Auth abuse mitigation.
- Storage files are private through Worker and RLS; files are **not** served from a public bucket. Before enabling arbitrary PDFs/ZIPs at scale, add malware scanning, stricter file quotas and retention policies.
- Streamed messages are stored only once the model finishes; interrupted replies show an error. User messages may remain saved if provider fails.
- Supabase table queries require internet; offline behavior shows an error and leaves the visible UI. Offline queue/sync conflict resolution is **not implemented**.
- Password recovery redirect needs testing on signed mobile builds. Confirm full account-deletion flows (including R2) before release.
- Push notifications, social OAuth, speech, image/video generation, Claude/Gemini/DeepSeek integrations, agent web tools, cron and payment/billing not included in this foundation.
- Neither credentials nor deployment permissions were provided to this build environment, so **no live deployment/email/binary was verified** in this delivery.


## Optional IPA build for TrollStore-compatible older iPhones

See [`TROLLSTORE-BUILD.md`](TROLLSTORE-BUILD.md) and `.github/workflows/build-trollstore-ipa.yml`. This unsigned GitHub Actions build does not require Apple Developer signing, but **requires a real macOS runner, actual backend configuration, and a successful build**. Expo SDK 58 minimum iOS is 16.4, while TrollStore supports iOS through 17.0 only. The workflow has **not** been run or verified in this conversation.
