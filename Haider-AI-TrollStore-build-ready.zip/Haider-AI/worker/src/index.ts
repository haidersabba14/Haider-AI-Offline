import { createClient, type SupabaseClient } from '@supabase/supabase-js';

interface Env {
  SUPABASE_URL: string;
  SUPABASE_PUBLISHABLE_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY?: string; // server secret, only used for queue/admin operations
  OPENAI_API_KEY: string; // server secret
  OPENAI_MODEL?: string;
  FILES_BUCKET?: R2Bucket;
  TASK_QUEUE?: Queue<{ taskId: string; userId: string }>;
}

type Identity = { id: string; db: SupabaseClient };
const HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: HEADERS });
const failure = (status: number, message: string) => json({ error: message }, status);
const bodyLimit = 10000;
const fileLimit = 10 * 1024 * 1024;
const validMimes = new Set(['image/png','image/jpeg','image/webp','application/pdf','text/plain','application/zip']);

function admin(env: Env) {
  if (!env.SUPABASE_SERVICE_ROLE_KEY) throw new Error('Admin secret not configured');
  return createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}
function scopedDb(env: Env, bearer: string) {
  return createClient(env.SUPABASE_URL, env.SUPABASE_PUBLISHABLE_KEY, {
    global: { headers: { Authorization: `Bearer ${bearer}` } },
    auth: { autoRefreshToken: false, persistSession: false }
  });
}
async function identify(req: Request, env: Env): Promise<Identity | null> {
  const match = /^Bearer\s+(\S+)$/i.exec(req.headers.get('authorization') ?? '');
  if (!match || !env.SUPABASE_URL || !env.SUPABASE_PUBLISHABLE_KEY) return null;
  const db = scopedDb(env, match[1]);
  const { data, error } = await db.auth.getUser(match[1]); // validates with Supabase Auth, not a decoded claim
  if (error || !data.user) return null;
  return { id: data.user.id, db };
}
async function openAI(env: Env, messages: { role: string; content: string }[], stream: boolean) {
  if (!env.OPENAI_API_KEY) throw new Error('AI not configured');
  return fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: env.OPENAI_MODEL || 'gpt-4.1-mini', messages, stream, max_completion_tokens: 1200, ...(stream ? { stream_options: { include_usage: true } } : {}) })
  });
}
function encodeEvent(name: string, value: unknown) {
  return `event: ${name}\ndata: ${JSON.stringify(value)}\n\n`;
}
async function chat(req: Request, env: Env, identity: Identity): Promise<Response> {
  let input: { text?: unknown; conversationId?: unknown };
  try { input = await req.json(); } catch { return failure(400, 'صيغة الطلب غير صحيحة'); }
  const text = typeof input.text === 'string' ? input.text.trim() : '';
  if (!text || text.length > 6000) return failure(400, 'الرسالة يجب ألا تتجاوز 6000 حرف');
  if (input.conversationId != null && (typeof input.conversationId !== 'string' || !/^[0-9a-f-]{36}$/i.test(input.conversationId))) return failure(400, 'معرّف المحادثة غير صالح');
  const { data: allowed, error: quotaError } = await identity.db.rpc('claim_chat_quota');
  if (quotaError) return failure(503, 'تعذّر التحقق من حدود الاستخدام');
  if (!allowed) return failure(429, 'وصلت إلى حد 30 طلبًا في الساعة');
  let conversationId = input.conversationId as string | undefined;
  if (conversationId) {
    const { data, error } = await identity.db.from('conversations').select('id').eq('id', conversationId).single();
    if (error || !data) return failure(404, 'المحادثة غير متاحة');
  } else {
    const { data, error } = await identity.db.from('conversations')
      .insert({ user_id: identity.id, title: text.slice(0, 52) }).select('id').single();
    if (error || !data) return failure(500, 'تعذّر إنشاء المحادثة');
    conversationId = data.id;
  }
  const { error: messageError } = await identity.db.from('messages').insert({
    conversation_id: conversationId, user_id: identity.id, role: 'user', content: text
  });
  if (messageError) return failure(500, 'تعذّر حفظ الرسالة');
  const { data: rows, error: historyError } = await identity.db.from('messages')
    .select('role,content').eq('conversation_id', conversationId)
    .order('created_at', { ascending: false }).limit(20);
  if (historyError) return failure(500, 'تعذّر تحميل سياق المحادثة');
  const messages = [
    { role: 'system', content: 'You are HAIDER CORE, the helpful multilingual assistant in Haider AI. Be truthful, clear and safe. Reply in the same language as the user by default. Never claim to have completed external actions without actual tool access.' },
    ...((rows ?? []).reverse().map((m) => ({ role: m.role, content: m.content })))
  ];
  let provider: Response;
  try { provider = await openAI(env, messages, true); }
  catch { return failure(503, 'مزود الذكاء الاصطناعي غير مهيأ'); }
  if (!provider.ok || !provider.body) {
    // Do not expose API key / upstream details to clients.
    return failure(502, 'فشل طلب مزود الذكاء الاصطناعي، تأكد من إعداداته ورصيده');
  }
  const aiReader = provider.body.getReader();
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const db = identity.db;
  const ownerId = identity.id;
  const conv = conversationId;
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: string, value: unknown) => controller.enqueue(encoder.encode(encodeEvent(event, value)));
      send('meta', { conversationId: conv });
      let buffer = '';
      let assembled = '';
      let usage: { prompt_tokens?: number; completion_tokens?: number } = {};
      try {
        for (;;) {
          const { value, done } = await aiReader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const events = buffer.split(/\r?\n\r?\n/);
          buffer = events.pop() || '';
          for (const event of events) {
            for (const line of event.split(/\r?\n/)) {
              if (!line.startsWith('data:')) continue;
              const payload = line.slice(5).trim();
              if (payload === '[DONE]') continue;
              let parsed: any;
              try { parsed = JSON.parse(payload); } catch { continue; }
              const delta: string = parsed.choices?.[0]?.delta?.content || '';
              if (delta) {
                assembled += delta;
                if (assembled.length > 60000) throw new Error('Response too long');
                send('token', { text: delta });
              }
              if (parsed.usage) usage = parsed.usage;
            }
          }
        }
        if (!assembled.trim()) throw new Error('Empty provider response');
        const { error } = await db.from('messages').insert({ user_id: ownerId, conversation_id: conv, role: 'assistant', content: assembled });
        if (error) throw new Error('Unable to persist assistant response');
        await db.from('conversations').update({ updated_at: new Date().toISOString() }).eq('id', conv);
        if (env.SUPABASE_SERVICE_ROLE_KEY) {
          try { await admin(env).from('usage_records').insert({ user_id: ownerId, model: env.OPENAI_MODEL || 'gpt-4.1-mini', provider: 'openai', input_tokens: usage.prompt_tokens || 0, output_tokens: usage.completion_tokens || 0 }); }
          catch { /* telemetry failure should not break saved answer */ }
        }
        send('done', { saved: true });
      } catch {
        // This is not a successful completed response; UI must show error.
        try { send('error', { error: 'انقطع الرد أو تعذّر حفظ المحادثة' }); } catch { /* disconnected client */ }
      } finally {
        try { controller.close(); } catch { /* client disconnected */ }
        try { await aiReader.cancel(); } catch { /* already closed */ }
      }
    },
    cancel() { void aiReader.cancel(); }
  });
  return new Response(stream, { headers: {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-store, no-transform',
    'X-Content-Type-Options': 'nosniff',
    Connection: 'keep-alive'
  } });
}
async function upload(req: Request, env: Env, identity: Identity, url: URL) {
  if (!env.FILES_BUCKET) return failure(503, 'خدمة التخزين لم تُفعّل بعد');
  const size = Number(req.headers.get('content-length'));
  const mime = (req.headers.get('content-type') || '').split(';')[0].toLowerCase();
  const filename = (url.searchParams.get('filename') || 'file').replace(/[\\/\x00-\x1f]/g, '_').slice(0, 150);
  if (!Number.isSafeInteger(size) || size < 1 || size > fileLimit || !validMimes.has(mime)) return failure(400, 'نوع الملف غير مدعوم أو حجمه أكبر من 10MB');
  if (!req.body) return failure(400, 'ملف فارغ');
  const key = `${identity.id}/${crypto.randomUUID()}`;
  const file = await env.FILES_BUCKET.put(key, req.body, { httpMetadata: { contentType: mime }, customMetadata: { filename } });
  if (!file || file.size !== size) { await env.FILES_BUCKET.delete(key); return failure(400, 'فشل التحقق من حجم الملف'); }
  const { data, error } = await identity.db.from('generated_files').insert({ user_id: identity.id, filename, mime_type: mime, size_bytes: file.size, r2_key: key }).select('id').single();
  if (error || !data) { await env.FILES_BUCKET.delete(key); return failure(500, 'فشل تسجيل الملف'); }
  return json({ id: data.id, filename, size: file.size }, 201);
}
async function getFile(env: Env, identity: Identity, id: string) {
  if (!env.FILES_BUCKET) return failure(503, 'التخزين غير متصل');
  const { data, error } = await identity.db.from('generated_files').select('r2_key,mime_type,filename').eq('id', id).single();
  if (error || !data) return failure(404, 'الملف غير متاح');
  if (!data.r2_key.startsWith(`${identity.id}/`)) return failure(403, 'غير مسموح');
  const object = await env.FILES_BUCKET.get(data.r2_key);
  if (!object) return failure(404, 'الملف غير موجود');
  return new Response(object.body, { headers: {
    'Content-Type': data.mime_type, 'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(data.filename)}`,
    'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff'
  } });
}
async function createTask(req: Request, env: Env, identity: Identity) {
  if (!env.TASK_QUEUE || !env.SUPABASE_SERVICE_ROLE_KEY) return failure(503, 'خدمة المهام غير متصلة بعد');
  let data: { prompt?: unknown };
  try { data = await req.json(); } catch { return failure(400, 'طلب غير صالح'); }
  if (typeof data.prompt !== 'string' || !data.prompt.trim() || data.prompt.length > 3000) return failure(400, 'المهمة غير صالحة');
  const { data: allowed } = await identity.db.rpc('claim_chat_quota');
  if (!allowed) return failure(429, 'وصلت إلى حد الطلبات');
  const { data: task, error } = await identity.db.from('ai_tasks')
    .insert({ user_id: identity.id, kind: 'research', prompt: data.prompt.trim() }).select('id').single();
  if (error || !task) return failure(500, 'تعذّر إنشاء المهمة');
  try { await env.TASK_QUEUE.send({ taskId: task.id, userId: identity.id }); }
  catch { await identity.db.from('ai_tasks').update({ status: 'failed', error: 'Queue unavailable' }).eq('id', task.id); return failure(503, 'تعذّر إرسال المهمة إلى الطابور'); }
  return json({ taskId: task.id, status: 'queued' }, 202);
}
async function deleteAccount(env: Env, identity: Identity) {
  if (!env.SUPABASE_SERVICE_ROLE_KEY) return failure(503, 'حذف الحساب غير مهيأ');
  const service = admin(env);
  // Delete bucket objects before deleting auth user (DB rows cascade on auth deletion).
  const { count, error: countError } = await service.from('generated_files').select('id', { head: true, count: 'exact' }).eq('user_id', identity.id);
  if (countError) return failure(500, 'تعذّر مراجعة ملفات الحساب');
  if ((count || 0) > 0 && !env.FILES_BUCKET) return failure(503, 'وصل التخزين مطلوب لإزالة الملفات');
  if (env.FILES_BUCKET) {
    let cursor: string | undefined;
    do {
      const result = await env.FILES_BUCKET.list({ prefix: `${identity.id}/`, cursor });
      if (result.objects.length) await env.FILES_BUCKET.delete(result.objects.map(o => o.key));
      cursor = result.truncated ? result.cursor : undefined;
    } while (cursor);
  }
  const { error } = await service.auth.admin.deleteUser(identity.id);
  if (error) return failure(500, 'تعذّر إتمام حذف الحساب');
  return json({ deleted: true });
}
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === '/v1/health' && request.method === 'GET') return json({ application: 'Haider AI', running: true });
    if (!env.SUPABASE_URL || !env.SUPABASE_PUBLISHABLE_KEY) return failure(503, 'قاعدة البيانات غير مهيأة');
    let identity: Identity | null;
    try { identity = await identify(request, env); } catch { return failure(503, 'خدمة المصادقة غير متاحة'); }
    if (!identity) return failure(401, 'يلزم تسجيل الدخول');
    try {
      if (url.pathname === '/v1/chat' && request.method === 'POST') return await chat(request, env, identity);
      if (url.pathname === '/v1/files' && request.method === 'PUT') return await upload(request, env, identity, url);
      if (/^\/v1\/files\/[0-9a-f-]{36}$/i.test(url.pathname) && request.method === 'GET') return await getFile(env, identity, url.pathname.split('/')[3]);
      if (url.pathname === '/v1/tasks' && request.method === 'POST') return await createTask(request, env, identity);
      if (url.pathname === '/v1/account' && request.method === 'DELETE') return await deleteAccount(env, identity);
      return failure(404, 'المسار غير موجود');
    } catch { return failure(500, 'خطأ في الخدمة'); }
  },
  async queue(batch: MessageBatch<{ taskId: string; userId: string }>, env: Env) {
    const service = admin(env); // trusted Cloudflare Queue, never a public HTTP entry point
    for (const message of batch.messages) {
      const { taskId, userId } = message.body;
      const { data: task, error } = await service.from('ai_tasks').select('prompt,status')
        .eq('id', taskId).eq('user_id', userId).single();
      if (error || !task || task.status !== 'queued') { message.ack(); continue; }
      await service.from('ai_tasks').update({ status: 'working', updated_at: new Date().toISOString() }).eq('id', taskId).eq('user_id', userId);
      try {
        const response = await openAI(env, [
          { role: 'system', content: 'You are HAIDER CORE. Answer accurately; no browsing access. Say when you cannot verify new information.' },
          { role: 'user', content: task.prompt }
        ], false);
        if (!response.ok) throw new Error('Provider failure');
        const payload: any = await response.json();
        const result = String(payload.choices?.[0]?.message?.content || '');
        if (!result) throw new Error('Empty result');
        await service.from('ai_tasks').update({ status: 'done', result, updated_at: new Date().toISOString() }).eq('id', taskId).eq('user_id', userId);
        message.ack();
      } catch {
        if (message.attempts >= 3) {
          await service.from('ai_tasks').update({ status: 'failed', error: 'Provider unavailable', updated_at: new Date().toISOString() }).eq('id', taskId).eq('user_id', userId);
          message.ack();
        } else {
          await service.from('ai_tasks').update({ status: 'queued' }).eq('id', taskId).eq('user_id', userId);
          message.retry({ delaySeconds: 30 });
        }
      }
    }
  }
} satisfies ExportedHandler<Env, { taskId: string; userId: string }>;
